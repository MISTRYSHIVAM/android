package Notes;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;

public class DbManager {
    private final Context context;
    private DatabaseHelper databasehelper;
    private SQLiteDatabase sqlitedatabase;

    public DbManager(Context context) {
        this.context = context;
    }

    public void openDb() throws SQLException {
        databasehelper = new DatabaseHelper(context);
        sqlitedatabase = databasehelper.getWritableDatabase();
    }

    public void closeDb() { databasehelper.close(); }

    public long insertNotes(Notes note){
        ContentValues contentValues = new ContentValues();
        contentValues.put(Notes.c_notes_title,note.getNoteTitle());
        contentValues.put(Notes.c_notes_description,note.getNoteDescription());
        return sqlitedatabase.insert(Notes.TABLE_NAME,null,contentValues);
    }

    public ArrayList<Notes> getNotes(){
        ArrayList<Notes> newArraylist = new ArrayList<>();
        Cursor cursor = sqlitedatabase.rawQuery("select * from "+Notes.TABLE_NAME , null);
        while (cursor.moveToNext()){
            int id = cursor.getInt(0);
            String title = cursor.getString(1);
            String description = cursor.getString(2);
            Notes newNote = new Notes();
            newNote.setId(id);
            newNote.setNoteTitle(title);
            newNote.setNoteDescription(description);
            newArraylist.add(newNote);
        }
        return newArraylist;
    }

    public long updateNotes(Notes note){
        ContentValues contentValues = new ContentValues();
        contentValues.put(Notes.c_notes_title,note.getNoteTitle());
        contentValues.put(Notes.c_notes_description,note.getNoteDescription());
        return sqlitedatabase.update(Notes.TABLE_NAME,contentValues,Notes.c_notes_id + " = "+note.getId(),null);
    }

    public void deleteNotes(Notes note){
        sqlitedatabase.delete(Notes.TABLE_NAME,Notes.c_notes_id + " = "+note.getId() ,null );
    }

}
