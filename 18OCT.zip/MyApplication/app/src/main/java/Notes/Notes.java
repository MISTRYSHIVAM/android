package Notes;

import java.io.Serializable;

public class Notes implements Serializable {
    String noteTitle , noteDescription;
    int id;

public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static final String TABLE_NAME = "notes";
    public static final String c_notes_id = "noteId";
    public static final String c_notes_title = "note_title";
    public static final String c_notes_description = "note_description";
    public static final String SQL_CREATE_ENTITY =
            "CREATE TABLE "+TABLE_NAME+" (" +
                    c_notes_id+" INTEGER PRIMARY KEY ," +
                    c_notes_title+" TEXT ," +
                    c_notes_description+" TEXT )";
    public static final String SQL_DELETE_ENTITY = "DROP TABLE IF EXIST "+TABLE_NAME;


    Notes(){};
    Notes(String noteTitle , String noteDescription){
        this.noteTitle = noteTitle;
        this.noteDescription = noteDescription;
    }

    public String getNoteTitle() {
        return noteTitle;
    }

    public void setNoteTitle(String noteTitle) {
        this.noteTitle = noteTitle;
    }

    public String getNoteDescription() {
        return noteDescription;
    }

    public void setNoteDescription(String noteDescription) {
        this.noteDescription = noteDescription;
    }
}
