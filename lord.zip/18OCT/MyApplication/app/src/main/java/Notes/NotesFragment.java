package Notes;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.example.myapplication.R;
import com.google.android.material.textfield.TextInputLayout;

public class NotesFragment extends Fragment {
    Button saveBtn;
    NotesActivity notesActivity;
    TextInputLayout title , description;

    public boolean isEditMode = false;
    public Notes notes;

    public NotesFragment() {
        // Required empty public constructor
    }
    public NotesFragment(Notes note) {
        // Required empty public constructor
        this.notes = note;
        isEditMode = true;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notes, container, false);
        init(view);
        clickListener();
        return view;
    }

    public void clickListener(){
        saveBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(isEditMode){
                    Notes upNotes = new Notes(title.getEditText().getText().toString() , description.getEditText().getText().toString());
                    upNotes.setId(notes.getId());
//                    Log.e("title ",title.getEditText().getText().toString());
//                    Log.e("description ",description.getEditText().getText().toString());
//                    Log.e("Afected Row", String.valueOf((int)));
                    notesActivity.dbManager.updateNotes(upNotes);
                }else{
                    String noteTitle = title.getEditText().getText().toString();
                    String noteDescription = description.getEditText().getText().toString();

                    Notes newNote = new Notes();
                    newNote.setNoteTitle(noteTitle);
                    newNote.setNoteDescription(noteDescription);

                    notesActivity.dbManager.insertNotes(newNote);
                }
                getActivity().getSupportFragmentManager().popBackStack();
            }
        });
    }

    public void init(View view){
        saveBtn = view.findViewById(R.id.saveBtn);
        title = view.findViewById(R.id.noteTitle);
        description = view.findViewById(R.id.noteDescription);

        if(isEditMode){
            setDataToUpdate();
        }
    }

    public void setDataToUpdate(){
        title.getEditText().setText(notes.getNoteTitle());
        description.getEditText().setText(notes.getNoteDescription());
        saveBtn.setText("Update");
    }
    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        notesActivity = (NotesActivity) getActivity();
    }
}