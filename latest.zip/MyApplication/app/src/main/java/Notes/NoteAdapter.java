package Notes;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class NoteAdapter extends RecyclerView.Adapter<NoteViewHolder> {
    private ArrayList<Notes> notes = new ArrayList<>();
    @NonNull
    @Override
    public NoteViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.itemnotes,parent,false);
        NoteViewHolder viewHolder = new NoteViewHolder(v);
        return viewHolder;
    }

    @Override
    public int getItemCount() {
        return notes.size();
    }

    @Override
    public void onBindViewHolder(@NonNull NoteViewHolder holder, int position) {
        Notes note = notes.get(position);
        Log.e("TAG","NOte: " + note.getNoteTitle());
        holder.tvTitle.setText(note.getNoteTitle());
        holder.tvDescription.setText(note.getNoteDescription());
    }

    public  void setNotes(ArrayList<Notes> list){
        for (Notes item:
             list) {
            Log.e("TAG","Item: " + item.getNoteTitle());
        }
        notes.clear();
        notes.addAll(list);
        notifyDataSetChanged();
    }
}
