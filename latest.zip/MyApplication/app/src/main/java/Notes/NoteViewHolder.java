package Notes;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.myapplication.R;

public class NoteViewHolder extends RecyclerView.ViewHolder {
    TextView tvTitle , tvDescription;
    public NoteViewHolder(@NonNull View itemView) {
        super(itemView);
        tvTitle = itemView.findViewById(R.id.tvtitle);
        tvDescription = itemView.findViewById(R.id.description);
    }
}
