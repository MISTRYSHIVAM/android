package com.rlw.demoapplication.fragments;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AutoCompleteTextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.datepicker.CalendarConstraints;
import com.google.android.material.datepicker.DateValidatorPointBackward;
import com.google.android.material.datepicker.MaterialDatePicker;
import com.google.android.material.textfield.TextInputLayout;
import com.rlw.demoapplication.EmployeeActivity;
import com.rlw.demoapplication.R;
import com.rlw.demoapplication.model.Employees;
import com.rlw.demoapplication.model.Salary;
import com.rlw.demoapplication.utility.DateMask;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Objects;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class EmployeeFragment extends Fragment {

    private EmployeeActivity employeeActivity;
    private TextInputLayout wrpBirthdate, wrpFirstName, wrpLastName, wrpGender, wrpHireDate, wrpSalary;
    private AutoCompleteTextView actvGender;
    private MaterialButton btnSave;
    private boolean hasDataError = false;
    private Employees employees;
    private boolean isEditMode = false;

    public EmployeeFragment() {
        // Required empty public constructor
    }

    public EmployeeFragment(Employees employees) {
        this.employees = employees;
        isEditMode = true;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_employee, container, false);
        init(view);
        clickListeners();
        return view;
    }

    private void init(View view) {
        wrpBirthdate = view.findViewById(R.id.wrpBirthdate);
        wrpFirstName = view.findViewById(R.id.wrpFirstName);
        wrpLastName = view.findViewById(R.id.wrpLastName);
        wrpGender = view.findViewById(R.id.wrpGender);
        actvGender = view.findViewById(R.id.actvGender);
        wrpHireDate = view.findViewById(R.id.wrpHireDate);
        wrpSalary = view.findViewById(R.id.wrpSalary);
        btnSave = view.findViewById(R.id.btnSave);
        Objects.requireNonNull(wrpBirthdate.getEditText()).addTextChangedListener(new DateMask(wrpBirthdate));
        Objects.requireNonNull(wrpHireDate.getEditText()).addTextChangedListener(new DateMask(wrpHireDate));
        textChangeListener(wrpFirstName);
        textChangeListener(wrpLastName);
        textChangeListener(wrpGender);
        textChangeListener(wrpSalary);
        wrpSalary.setVisibility(View.GONE);

        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        if (isEditMode) {
            wrpSalary.setVisibility(View.VISIBLE);
            toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_24);
            toolbar.setNavigationIconTint(Color.WHITE);
            toolbar.setTitle("Update Employee Details");
            toolbar.setNavigationOnClickListener(view1 -> {
                getParentFragmentManager().popBackStack();
                employeeActivity.bottomNavigationView.setVisibility(View.VISIBLE);
            });
            setDateOnEditText();
        }
    }

    private void setDateOnEditText() {
        wrpFirstName.getEditText().setText(employees.getFirst_name());
        wrpLastName.getEditText().setText(employees.getLast_name());
        wrpBirthdate.getEditText().setText(employees.getBirth_date());
        wrpHireDate.getEditText().setText(employees.getHire_date());
        wrpGender.getEditText().setText(employees.getGender());
        Cursor cursor = employeeActivity.dbManager.getById(Salary.TABLE_NAME, Salary.WHERE + employees.getEmp_no());
        ArrayList<Salary> list = Salary.getSalaryData(cursor);
        if (list.size() == 1) {
            wrpSalary.getEditText().setText(list.get(0).getSalary());
        }
    }

    private void clickListeners() {
        Objects.requireNonNull(wrpBirthdate.getEditText()).setOnClickListener(v -> {
            String bod = wrpBirthdate.getEditText().getText().toString();
            Calendar bodCalendar = Calendar.getInstance();
            if (!bod.isEmpty()) {
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                Date date;
                try {
                    date = formatter.parse(bod);
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                bodCalendar.setTime(date);
            } else {
                bodCalendar.add(Calendar.YEAR, -18);
            }
            Calendar calendar = Calendar.getInstance();
            calendar.add(Calendar.YEAR, -18);


            CalendarConstraints.Builder calConst = new CalendarConstraints.Builder().setEnd(calendar.getTimeInMillis()).setOpenAt(bodCalendar.getTimeInMillis()).setValidator(DateValidatorPointBackward.before(calendar.getTimeInMillis()));
            MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker().setTitleText("Select Birthdate").setCalendarConstraints(calConst.build()).setSelection(dateFromUTC(bodCalendar.getTime()).getTime()).build();
            datePicker.show(getChildFragmentManager(), "tag");
            datePicker.addOnPositiveButtonClickListener(selection -> {
                try {
                    SimpleDateFormat to = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat from = new SimpleDateFormat("MMM dd, yyyy");
                    Date date = from.parse(datePicker.getHeaderText());
                    String result = to.format(date);
                    wrpBirthdate.getEditText().setText(result);
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

            });
        });

        Objects.requireNonNull(wrpHireDate.getEditText()).setOnClickListener(v -> {
            String bod = wrpHireDate.getEditText().getText().toString();
            Calendar bodCalendar = Calendar.getInstance();
            if (!bod.isEmpty()) {
                SimpleDateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
                Date date;
                try {
                    date = formatter.parse(bod);
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }
                bodCalendar.setTime(date);
            }
            Calendar calendar = Calendar.getInstance();


            CalendarConstraints.Builder calConst = new CalendarConstraints.Builder().setEnd(calendar.getTimeInMillis()).setOpenAt(bodCalendar.getTimeInMillis()).setValidator(DateValidatorPointBackward.before(calendar.getTimeInMillis()));
            MaterialDatePicker<Long> datePicker = MaterialDatePicker.Builder.datePicker().setTitleText("Select Hire date").setCalendarConstraints(calConst.build()).setSelection(dateFromUTC(bodCalendar.getTime()).getTime()).build();
            datePicker.show(getChildFragmentManager(), "tag");
            datePicker.addOnPositiveButtonClickListener(selection -> {
                try {
                    SimpleDateFormat to = new SimpleDateFormat("dd/MM/yyyy");
                    SimpleDateFormat from = new SimpleDateFormat("MMM dd, yyyy");
                    Date date = from.parse(datePicker.getHeaderText());
                    String result = to.format(date);
                    wrpHireDate.getEditText().setText(result);
                } catch (ParseException e) {
                    throw new RuntimeException(e);
                }

            });
        });

        btnSave.setOnClickListener(v -> {
            hasDataError = false;
            String firstName = wrpFirstName.getEditText().getText().toString();
            String lastName = wrpLastName.getEditText().getText().toString();
            String birthDate = wrpBirthdate.getEditText().getText().toString();
            String gender = actvGender.getText().toString();
            String hireDate = wrpHireDate.getEditText().getText().toString();
            String salary = wrpSalary.getEditText().getText().toString();
            setError(firstName, wrpFirstName);
            setError(lastName, wrpLastName);
            setError(birthDate, wrpBirthdate);
            setError(gender, wrpGender);
            setError(gender, wrpHireDate);

            if (isEditMode) {
                setError(salary, wrpSalary);
            } else {
                salary = "";
            }
            if (hasDataError) return;

            if (isEditMode) {
                ContentValues empContentValues = Employees.getEmpContentValue(firstName, lastName, birthDate, gender, hireDate);
                long id = employeeActivity.dbManager.update(Employees.TABLE_TABLE, empContentValues, Employees.WHERE + employees.getEmp_no());
                ContentValues salContentValues = Salary.getSalaryContentValue((int) id, salary);
                long sId = employeeActivity.dbManager.update(Salary.TABLE_NAME, salContentValues, Salary.WHERE + id);
                if (id != -1 && sId != -1) {
                    Toast.makeText(getContext(), "Record updated", Toast.LENGTH_SHORT).show();
                    getParentFragmentManager().popBackStack();
                    employeeActivity.bottomNavigationView.setVisibility(View.VISIBLE);
                } else {
                    Toast.makeText(getContext(), "Error while updating record", Toast.LENGTH_SHORT).show();
                }
            } else {
                ContentValues empContentValues = Employees.getEmpContentValue(firstName, lastName, birthDate, gender, hireDate);
                long id = employeeActivity.dbManager.insert(Employees.TABLE_TABLE, empContentValues);
                ContentValues salContentValues = Salary.getSalaryContentValue((int) id, salary);
                long sId = employeeActivity.dbManager.insert(Salary.TABLE_NAME, salContentValues);
                if (id != -1 && sId != -1) {
                    Toast.makeText(getContext(), "Record stored", Toast.LENGTH_SHORT).show();
                    clearForm();
                } else {
                    Toast.makeText(getContext(), "Error while adding record", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private void clearForm() {
        wrpFirstName.getEditText().setText("");
        wrpLastName.getEditText().setText("");
        wrpGender.getEditText().setText("");
        wrpBirthdate.getEditText().setText("");
        wrpHireDate.getEditText().setText("");
    }

    public Date dateFromUTC(Date date) {
        return new Date(date.getTime() + Calendar.getInstance().getTimeZone().getOffset(new Date().getTime()));
    }

    private void setError(String value, TextInputLayout textInputLayout) {
        if (value.isEmpty()) {
            hasDataError = true;
            textInputLayout.setError("Please enter valid data");
        }
    }

    private void textChangeListener(TextInputLayout textInputLayout) {
        textInputLayout.getEditText().addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                if (!textInputLayout.getEditText().getText().toString().isEmpty()) {
                    textInputLayout.setError("");
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }
}