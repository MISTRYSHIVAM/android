package com.rlw.demoapplication.utility;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import com.rlw.demoapplication.model.Employees;
import com.rlw.demoapplication.model.Salary;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DB_NAME = "employees.db";
    private static final int DB_VERSION = 1;


    public DatabaseHelper(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(Employees.CREATE_EMP_TABLE);
        sqLiteDatabase.execSQL(Salary.CREATE_SALARY_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int oldVersion, int newVersion) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Employees.TABLE_TABLE);
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + Salary.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }
}
