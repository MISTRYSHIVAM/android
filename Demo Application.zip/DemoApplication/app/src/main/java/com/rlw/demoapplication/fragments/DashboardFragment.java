package com.rlw.demoapplication.fragments;

import android.content.Context;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.rlw.demoapplication.EmployeeActivity;
import com.rlw.demoapplication.R;
import com.rlw.demoapplication.fragments.adapter.EmpItemClickListeners;
import com.rlw.demoapplication.fragments.adapter.EmployeeAdapter;
import com.rlw.demoapplication.model.Employees;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class DashboardFragment extends Fragment implements EmpItemClickListeners {


    private EmployeeAdapter employeeAdapter;
    private EmployeeActivity employeeActivity;

    public DashboardFragment() {
        // Required empty public constructor
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_home, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        RecyclerView recyclerView = view.findViewById(R.id.rclEmp);
        employeeAdapter = new EmployeeAdapter(this);
        recyclerView.setAdapter(employeeAdapter);
        getEmpData();
    }

    private void getEmpData() {
        Cursor cursor = employeeActivity.dbManager.getAll(Employees.TABLE_TABLE);
        ArrayList<Employees> employeesArrayList = Employees.getAllEmployeeData(cursor);
        employeeAdapter.setEmpList(employeesArrayList);
    }

    @Override
    public void onItemEditClickListener(Employees employees) {
        employeeActivity.bottomNavigationView.setVisibility(View.GONE);
        EmployeeFragment employeeFragment = new EmployeeFragment(employees);
        getParentFragmentManager().beginTransaction().replace(R.id.demo_container, employeeFragment).addToBackStack("edit_emp").commit();
    }

    @Override
    public void onItemDeleteClickListener(Employees employees) {
        new MaterialAlertDialogBuilder(getContext()).setCancelable(false).setTitle(getResources().getString(R.string.deleteConfirmation)).setMessage(getResources().getString(R.string.deleteEmp)).setPositiveButton(getResources().getString(R.string.delete), (dialogInterface, i) -> {
            employeeActivity.dbManager.delete(Employees.TABLE_TABLE, Employees.WHERE + employees.getEmp_no());
            getEmpData();
        }).setNegativeButton(android.R.string.cancel, null).show();
    }

    @Override
    public void onItemDetailsClickListener(Employees employees) {
        employeeActivity.bottomNavigationView.setVisibility(View.GONE);
        DetailsFragment detailsFragment = new DetailsFragment(employees);
        getParentFragmentManager().beginTransaction().replace(R.id.demo_container, detailsFragment).addToBackStack("emp_details").commit();
    }
}