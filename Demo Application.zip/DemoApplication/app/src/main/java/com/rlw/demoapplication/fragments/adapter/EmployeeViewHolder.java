package com.rlw.demoapplication.fragments.adapter;

import android.animation.LayoutTransition;
import android.view.View;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;
import androidx.transition.AutoTransition;
import androidx.transition.TransitionManager;

import com.google.android.material.textview.MaterialTextView;
import com.rlw.demoapplication.R;

public class EmployeeViewHolder extends RecyclerView.ViewHolder {

    private final ConstraintLayout constraintLayout;
    public MaterialTextView tvName, tvDetails;
    public Button btnEdit, btnDelete, btnDetails;

    public EmployeeViewHolder(@NonNull View itemView) {
        super(itemView);
        tvName = itemView.findViewById(R.id.tvName);
        tvDetails = itemView.findViewById(R.id.tvDetails);
        constraintLayout = itemView.findViewById(R.id.llLayout);
        btnEdit = itemView.findViewById(R.id.btnEdit);
        btnDelete = itemView.findViewById(R.id.btnDelete);
        btnDetails = itemView.findViewById(R.id.btnDetails);
        constraintLayout.getLayoutTransition().enableTransitionType(LayoutTransition.CHANGING); //give transition type, you can change this based on your need
        constraintLayout.setOnClickListener(v -> {
            expand(tvDetails);
            expand(btnDetails);
        });
    }

    public void expand(View view) { //the function that given to onclick event
        int v = (view.getVisibility() == View.GONE) ? View.VISIBLE : View.GONE;
        TransitionManager.beginDelayedTransition(constraintLayout, new AutoTransition());
        view.setVisibility(v);
    }
}
