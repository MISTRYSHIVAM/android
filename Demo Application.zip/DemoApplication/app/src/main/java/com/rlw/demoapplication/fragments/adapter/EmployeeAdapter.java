package com.rlw.demoapplication.fragments.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.rlw.demoapplication.R;
import com.rlw.demoapplication.model.Employees;

import java.util.ArrayList;

public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeViewHolder> {
    private final ArrayList<Employees> empList = new ArrayList<>();
    private final EmpItemClickListeners empItemClickListeners;

    public EmployeeAdapter(EmpItemClickListeners empItemClickListeners) {
        this.empItemClickListeners = empItemClickListeners;
    }

    @NonNull
    @Override
    public EmployeeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(parent.getContext());
        View v = inflater.inflate(R.layout.item_employee, parent, false);
        return new EmployeeViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull EmployeeViewHolder holder, int position) {
        Employees employee = empList.get(position);
        holder.tvName.setText(employee.getFirst_name() + " " + employee.getLast_name());
        holder.tvDetails.setText("Gender: " + employee.getGender() + "\nBirth Date: " + employee.getBirth_date() + "\nHire Date: " + employee.getHire_date());
        holder.btnDelete.setOnClickListener(v -> {
            empItemClickListeners.onItemDeleteClickListener(employee);
        });
        holder.btnEdit.setOnClickListener(v -> {
            empItemClickListeners.onItemEditClickListener(employee);
        });
        holder.btnDetails.setOnClickListener(v -> {
            empItemClickListeners.onItemDetailsClickListener(employee);
        });
    }

    @Override
    public int getItemCount() {
        return empList.size();
    }

    public void setEmpList(ArrayList<Employees> list) {
        empList.clear();
        empList.addAll(list);
        notifyDataSetChanged();
    }
}
