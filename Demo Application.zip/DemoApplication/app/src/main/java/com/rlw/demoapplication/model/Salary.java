package com.rlw.demoapplication.model;

import android.content.ContentValues;
import android.database.Cursor;

import java.io.Serializable;
import java.util.ArrayList;

public class Salary implements Serializable {

    public static final String TABLE_NAME = "salary";
    private static final String c_id = "sId";
    public static final String WHERE = c_id + "=";
    private static final String c_salary = "salary";
    public static final String CREATE_SALARY_TABLE = "create table " + TABLE_NAME + "(" + c_id + " INTEGER," + c_salary + " TEXT);";
    int sId;
    String salary;

    public Salary() {
    }

    public Salary(int sId, String salary) {
        this.sId = sId;
        this.salary = salary;
    }

    public static ContentValues getSalaryContentValue(int id, String salary) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(c_id, id);
        contentValues.put(c_salary, salary);
        return contentValues;
    }

    public static ArrayList<Salary> getSalaryData(Cursor cursor) {
        ArrayList<Salary> salList = new ArrayList<>();
        while (cursor.moveToNext()) {
            Salary salary = new Salary(cursor.getInt(0), cursor.getString(1));
            salList.add(salary);
        }
        return salList;
    }

    public int getsId() {
        return sId;
    }

    public void setsId(int sId) {
        this.sId = sId;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

}
