package com.rlw.demoapplication.model;

import android.content.ContentValues;
import android.database.Cursor;

import java.io.Serializable;
import java.util.ArrayList;

public class Employees implements Serializable {
    public static final String TABLE_TABLE = "employees";
    private static final String c_emp_no = "emp_no";
    private static final String c_birth_date = "birth_date";
    private static final String c_first_name = "first_name";
    private static final String c_last_name = "last_name";
    private static final String c_gender = "gender";
    private static final String c_hire_date = "hire_date";

    public static final String WHERE = c_emp_no + "=";
    public static final String CREATE_EMP_TABLE =
            "create table " + TABLE_TABLE +
                    "(" + c_emp_no +
                    " INTEGER PRIMARY KEY AUTOINCREMENT," +
                    c_birth_date +
                    " TEXT," +
                    c_first_name +
                    " TEXT," +
                    c_last_name +
                    " TEXT," + c_gender + " TEXT," +
                    c_hire_date + " TEXT);";




















    int emp_no;
    String birth_date, first_name, last_name, gender, hire_date;
















    public Employees() {
    }

    public Employees(int emp_no, String birth_date, String first_name, String last_name, String gender, String hire_date) {
        this.emp_no = emp_no;
        this.birth_date = birth_date;
        this.first_name = first_name;
        this.last_name = last_name;
        this.gender = gender;
        this.hire_date = hire_date;
    }

    public static ContentValues getEmpContentValue(String fName,
String lName, String bod, String gender, String hire_date) {
        ContentValues contentValues = new ContentValues();
        contentValues.put(c_first_name, fName);
        contentValues.put(c_last_name, lName);
        contentValues.put(c_gender, gender);
        contentValues.put(c_birth_date, bod);
        contentValues.put(c_hire_date, hire_date);
        return contentValues;
    }

    public static ArrayList<Employees> getAllEmployeeData(Cursor cursor) {
        ArrayList<Employees> empList = new ArrayList<>();
        while (cursor.moveToNext()) {
            Employees employees = new Employees(cursor.getInt(0), cursor.getString(1), cursor.getString(2), cursor.getString(3), cursor.getString(4), cursor.getString(5));
            empList.add(employees);
        }
        return empList;
    }

    public int getEmp_no() {
        return emp_no;
    }

    public void setEmp_no(int emp_np) {
        this.emp_no = emp_np;
    }

    public String getBirth_date() {
        return birth_date;
    }

    public void setBirth_date(String birth_date) {
        this.birth_date = birth_date;
    }

    public String getFirst_name() {
        return first_name;
    }

    public void setFirst_name(String first_name) {
        this.first_name = first_name;
    }

    public String getLast_name() {
        return last_name;
    }

    public void setLast_name(String last_name) {
        this.last_name = last_name;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getHire_date() {
        return hire_date;
    }

    public void setHire_date(String hire_date) {
        this.hire_date = hire_date;
    }
}
