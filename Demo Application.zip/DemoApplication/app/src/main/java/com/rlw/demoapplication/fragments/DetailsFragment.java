package com.rlw.demoapplication.fragments;

import android.content.Context;
import android.database.Cursor;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.google.android.material.appbar.MaterialToolbar;
import com.google.android.material.textview.MaterialTextView;
import com.rlw.demoapplication.EmployeeActivity;
import com.rlw.demoapplication.R;
import com.rlw.demoapplication.model.Employees;
import com.rlw.demoapplication.model.Salary;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * create an instance of this fragment.
 */
public class DetailsFragment extends Fragment {

    private Employees employees;
    private boolean isShowDetails = false;
    private EmployeeActivity employeeActivity;

    public DetailsFragment() {
        // Required empty public constructor
    }

    public DetailsFragment(Employees employees) {
        this.employees = employees;
        isShowDetails = true;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        employeeActivity = (EmployeeActivity) getActivity();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_details, container, false);
        init(view);
        return view;
    }

    private void init(View view) {
        MaterialTextView tvDetails = view.findViewById(R.id.tvEmpDetails);
        MaterialToolbar toolbar = view.findViewById(R.id.toolbar);
        if (isShowDetails) {
            employeeActivity.bottomNavigationView.setVisibility(View.GONE);
            toolbar.setNavigationIcon(R.drawable.baseline_arrow_back_24);
            toolbar.setNavigationIconTint(Color.WHITE);
            toolbar.setNavigationOnClickListener(view1 -> {
                getParentFragmentManager().popBackStack();
                employeeActivity.bottomNavigationView.setVisibility(View.VISIBLE);
            });
            StringBuilder builder = new StringBuilder();
            builder.append("Name: ").append(employees.getFirst_name()).append(" ").append(employees.getLast_name()).append("\n").append("Gender: ").append(employees.getGender()).append("\n").append("Birth Date: ").append(employees.getBirth_date()).append("\n").append("Hire Date: ").append(employees.getHire_date());
            Cursor cursor = employeeActivity.dbManager.getById(Salary.TABLE_NAME, Salary.WHERE + employees.getEmp_no());
            ArrayList<Salary> list = Salary.getSalaryData(cursor);
            if (list.size() == 1) {
                builder.append("\n").append("Salary: ").append(list.get(0).getSalary());
            }
            tvDetails.setText(builder.toString());
        } else {
            tvDetails.setText(R.string.select_employee_to_see_details);
        }
    }
}