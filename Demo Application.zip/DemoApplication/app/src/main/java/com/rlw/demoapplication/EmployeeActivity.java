package com.rlw.demoapplication;

import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.activity.OnBackPressedCallback;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.rlw.demoapplication.fragments.DashboardFragment;
import com.rlw.demoapplication.fragments.DetailsFragment;
import com.rlw.demoapplication.fragments.EmployeeFragment;
import com.rlw.demoapplication.utility.DBManager;

public class EmployeeActivity extends AppCompatActivity {

    public BottomNavigationView bottomNavigationView;
    public DBManager dbManager;
    private DashboardFragment dashboardFragment;
    private DetailsFragment detailsFragment;
    private EmployeeFragment employeeFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        dbManager = new DBManager(this);
        dbManager.openDB();
        initComponent();

        getOnBackPressedDispatcher().addCallback(this, new OnBackPressedCallback(true) {
            @Override
            public void handleOnBackPressed() {
                if (getSupportFragmentManager().getBackStackEntryCount() > 0) {
                    getSupportFragmentManager().popBackStack();
                    bottomNavigationView.setVisibility(View.VISIBLE);
                } else {
                    finish();
                }
            }
        });

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        dbManager.closeDB();
    }

    private void initComponent() {
        bottomNavigationView = findViewById(R.id.bottomNav);
        dashboardFragment = new DashboardFragment();
        detailsFragment = new DetailsFragment();
        employeeFragment = new EmployeeFragment();
        bottomNavigationView.setSelectedItemId(R.id.dashboard);
        loadFragment(dashboardFragment);
        bottomNavigationView.setOnItemSelectedListener(item -> {
            int itemId = item.getItemId();
            if (itemId == R.id.dashboard) {
                loadFragment(dashboardFragment);
                return true;
            } else if (itemId == R.id.details) {
                loadFragment(detailsFragment);
                return true;
            } else if (itemId == R.id.add) {
                loadFragment(employeeFragment);
                return true;
            }
            return false;
        });
    }

    private void loadFragment(Fragment fragment) {
        getSupportFragmentManager()
                .beginTransaction()
                .replace(R.id.demo_container, fragment).commit();
    }


}