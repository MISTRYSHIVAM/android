package com.rlw.demoapplication.fragments.adapter;

import com.rlw.demoapplication.model.Employees;

public interface EmpItemClickListeners {
    void onItemEditClickListener(Employees employees);

    void onItemDeleteClickListener(Employees employees);

    void onItemDetailsClickListener(Employees employees);
}
