package Fragments.Adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admindashboard.R;

import java.util.ArrayList;

import Model.Employee;

public class EmployeeAdapter extends RecyclerView.Adapter<EmployeeViewHolder> {
    private ArrayList<Employee> employee =new ArrayList<>();

    @NonNull
    @Override
    public EmployeeViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater =LayoutInflater.from(parent.getContext());
        View v =inflater.inflate(R.layout.emplist,parent,false);
        EmployeeViewHolder viewHolder = new EmployeeViewHolder(v);
        return viewHolder;
    }

    @Override
    public int getItemCount() {
        return employee.size();
    }

    @Override
    public void onBindViewHolder(@NonNull EmployeeViewHolder holder, int position) {
        Employee emp = employee.get(position);
        holder.tvEmpFirstName.setText(emp.getEmpFirstName());
        holder.tvEmpLastName.setText(emp.getEmpLastName());
        holder.tvEmpAge.setText(emp.getEmpAge());
        holder.tvEmpGender.setText(emp.getEmpGender());
        holder.tvEmpWorkLocation.setText(emp.getEmpWorkLocation());
        holder.tvEmpEmail.setText(emp.getEmpEmail());
        holder.tvEmpMobileNo.setText(emp.getEmpMobileNo());
    }

    public void setEmployee(ArrayList<Employee> emp){
        employee.clear();
        employee.addAll(emp);
        notifyDataSetChanged();
    }
}
