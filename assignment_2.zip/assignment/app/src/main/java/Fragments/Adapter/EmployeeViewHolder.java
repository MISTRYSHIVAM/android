package Fragments.Adapter;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.admindashboard.R;

public class EmployeeViewHolder extends RecyclerView.ViewHolder {

    TextView tvEmpFirstName , tvEmpLastName ,tvEmpGender , tvEmpAge , tvEmpWorkLocation , tvEmpEmail, tvEmpMobileNo;
    public EmployeeViewHolder(@NonNull View itemView) {
        super(itemView);
        tvEmpFirstName = itemView.findViewById(R.id.tvFirstName);
        tvEmpLastName = itemView.findViewById(R.id.tvLastName);
        tvEmpGender = itemView.findViewById(R.id.tvGender);
        tvEmpAge = itemView.findViewById(R.id.tvAge);
        tvEmpWorkLocation = itemView.findViewById(R.id.tvWorkLocation);
        tvEmpEmail = itemView.findViewById(R.id.tvEmailId);
        tvEmpMobileNo = itemView.findViewById(R.id.tvMobileno);
    }
}
