package Utility;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DbManager {
    private final Context context;
    private DbHelper dbHelper;
    private SQLiteDatabase sqLiteDatabase;

    public DbManager(Context context){
        this.context = context;
    }

    public DbManager openDB() throws SQLException {
        dbHelper = new DbHelper(context);
        sqLiteDatabase = dbHelper.getWritableDatabase();
        return this;
    }

    public void closeDB() {
        dbHelper.close();
    }

    public long insert(String table, ContentValues value) {
        return sqLiteDatabase.insert(table, null, value);
    }

    public int update(String table, ContentValues value, String where) {
        return sqLiteDatabase.update(table, value, where, null);
    }

    public void delete(String table, String where) {
        sqLiteDatabase.delete(table, where, null);
    }

    public Cursor getAll(String table) {
        return sqLiteDatabase.rawQuery("select * from " + table, null);
    }

    public Cursor getById(String table, String where) {
        return sqLiteDatabase.rawQuery("select * from " + table + " where " + where, null);
    }
}
