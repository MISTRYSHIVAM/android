package Model;

public class Employee {

    public static final String TABLE_TABLE = "employees";
    private static final String c_emp_no = "emp_no";
    private static final String c_last_date = "last_date";
    private static final String c_first_name = "first_name";
    private static final String c_age = "age";
    private static final String c_gender = "gender";
    private static final String c_work_location = "work_location";
    private static final String c_email = "email";
    private static final String c_mobile_no = "mobile_no";

    private static final String WHERE = c_emp_no+" = ";
    public static final String CREATE_TABLE =
            "CREATE TABLE "+TABLE_TABLE +"( "+
                    c_emp_no +" INTEGER PRIMARY KEY AUTO INCREMENT ,"+
                    c_first_name +" TEXT ,"+
                    c_last_date +" TEXT ,"+
                    c_age +" INTEGER ,"+
                    c_gender + " TEXT ,"+
                    c_work_location + " TEXT,"+
                    c_email + " TEXT ,"+
                    c_mobile_no + " TEXT );";
    int empNo;
    String empFirstName , empLastName ,empGender ,empBirthDate , empAge ,empWorkLocation,empEmail,empMobileNo;

    public Employee(){};

    public Employee(int empNo, String empFirstName, String empLastName, String empGender, String empBirthDate, String empAge, String empWorkLocation, String empEmail, String empMobileNo) {
        this.empNo = empNo;
        this.empFirstName = empFirstName;
        this.empLastName = empLastName;
        this.empGender = empGender;
        this.empBirthDate = empBirthDate;
        this.empAge = empAge;
        this.empWorkLocation = empWorkLocation;
        this.empEmail = empEmail;
        this.empMobileNo = empMobileNo;
    }

    public int getEmpNo() {
        return empNo;
    }

    public void setEmpNo(int empNo) {
        this.empNo = empNo;
    }

    public String getEmpFirstName() {
        return empFirstName;
    }

    public void setEmpFirstName(String empFirstName) {
        this.empFirstName = empFirstName;
    }

    public String getEmpLastName() {
        return empLastName;
    }

    public void setEmpLastName(String empLastName) {
        this.empLastName = empLastName;
    }

    public String getEmpGender() {
        return empGender;
    }

    public void setEmpGender(String empGender) {
        this.empGender = empGender;
    }

    public String getEmpBirthDate() {
        return empBirthDate;
    }

    public void setEmpBirthDate(String empBirthDate) {
        this.empBirthDate = empBirthDate;
    }

    public String getEmpAge() {
        return empAge;
    }

    public void setEmpAge(String empAge) {
        this.empAge = empAge;
    }

    public String getEmpWorkLocation() {
        return empWorkLocation;
    }

    public void setEmpWorkLocation(String empWorkLocation) {
        this.empWorkLocation = empWorkLocation;
    }

    public String getEmpEmail() {
        return empEmail;
    }

    public void setEmpEmail(String empEmail) {
        this.empEmail = empEmail;
    }

    public String getEmpMobileNo() {
        return empMobileNo;
    }

    public void setEmpMobileNo(String empMobileNo) {
        this.empMobileNo = empMobileNo;
    }
}
