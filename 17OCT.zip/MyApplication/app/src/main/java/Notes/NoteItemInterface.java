package Notes;

public interface NoteItemInterface {
    public void onItemClickListener(Notes note);

    public void onItemLongClickListener(Notes note);
}
