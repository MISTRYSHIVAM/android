package Notes;

import android.app.Activity;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import com.example.myapplication.R;
import com.google.android.material.floatingactionbutton.ExtendedFloatingActionButton;

import java.util.ArrayList;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link NotesDetailsFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class NotesDetailsFragment extends Fragment implements NoteItemInterface {
    ExtendedFloatingActionButton addNoteBtn;
    NotesActivity notesActivity;

    // TODO: Rename parameter arguments, choose names that match
    // the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
    private static final String ARG_PARAM1 = "param1";
    private static final String ARG_PARAM2 = "param2";

    // TODO: Rename and change types of parameters
    private String mParam1;
    private String mParam2;

    public NotesDetailsFragment() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment NotesDetailsFragment.
     */
    // TODO: Rename and change types and number of parameters
    public static NotesDetailsFragment newInstance(String param1, String param2) {
        NotesDetailsFragment fragment = new NotesDetailsFragment();
        Bundle args = new Bundle();
        args.putString(ARG_PARAM1, param1);
        args.putString(ARG_PARAM2, param2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            mParam1 = getArguments().getString(ARG_PARAM1);
            mParam2 = getArguments().getString(ARG_PARAM2);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View view = inflater.inflate(R.layout.fragment_notes_details, container, false);
        init(view);
        clickListener();

        RecyclerView recyclerView = view.findViewById(R.id.recycleView);
        NoteAdapter noteAdapter = new NoteAdapter(this);
        noteAdapter.setNotes(getNotes());
        recyclerView.setAdapter(noteAdapter);

        return view;
    }


    public void init(View view){
        addNoteBtn = view.findViewById(R.id.addNote);
    }

    public void clickListener(){
        addNoteBtn.setOnClickListener(v -> {
            notesActivity.loadFragment(new NotesFragment());
        });
    }

    @Override
    public void onAttach(@NonNull Activity activity) {
        super.onAttach(activity);
        notesActivity = (NotesActivity) getActivity();
    }

    private ArrayList<Notes> getNotes(){
        ArrayList<Notes> notes = new ArrayList<>();
        notes.add(new Notes("Test 1","Description 1"));
        notes.add(new Notes("Test 2","Description 2"));
        notes.add(new Notes("Test 3","Description 3"));
        notes.add(new Notes("Test 4","Description 4"));
        return notes;
    }

    @Override
    public void onItemClickListener(Notes note) {
        Toast.makeText(notesActivity, note.getNoteTitle(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onItemLongClickListener(Notes note) {
        Toast.makeText(notesActivity, note.getNoteDescription(), Toast.LENGTH_SHORT).show();
    }
}