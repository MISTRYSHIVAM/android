package Notes;

import android.content.Context;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DbManager {
    private final Context context;
    private DatabaseHelper databasehelper;
    private SQLiteDatabase sqlitedatabase;

    public DbManager(Context context) {
        this.context = context;
    }

    public void openDb() throws SQLException {
        databasehelper = new DatabaseHelper(context);
        sqlitedatabase = databasehelper.getWritableDatabase();
    }

    public void closeDb() { databasehelper.close(); }

}
